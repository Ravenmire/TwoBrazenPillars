      DROP DATABASE IF EXISTS library;
    CREATE DATABASE library;
